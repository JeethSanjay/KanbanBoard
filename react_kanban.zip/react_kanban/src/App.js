import Kanban from './components/Kanban';

function App() {
  return (
    <>
      <Kanban />
    </>
  );
}

export default App;
